
# coding: utf-8

# In[1]:


import sys
import arcpy # This imports arcpy.


# In[2]:


arcpy.env.workspace = 'C:\Users\pwyate36\AppData\Roaming\ESRI\Desktop10.5\ArcCatalog\Connection_to_SDEPF.sde'
# This sets the workspace environment to the path for Proposed Features, this needs to be changed as necessary.

workspace = arcpy.env.workspace


# In[ ]:


# Disconnects users
print("The database is no longer accepting connections")
arcpy.AcceptConnections(workspace, False)


# In[3]:


versionList = arcpy.ListVersions(workspace) # This list is needed to collect all the versions of recreation later.

parentVersion = "sde.DEFAULT" # We need to set the parentVersion for use later, this can be changed as necessary.

print versionList


# In[4]:


userList = arcpy.ListUsers(workspace)
# We need a user list to determine who is logged on at the time, we can only have one SDE connection to compress properly.

print userList


# In[5]:


nameList = [] # We need a list to convert the unicode versions into strings to split them based on owner and job title.

i = 0

while(i < len(versionList)): # I used a while loop here to guarantee it will run through any possible amount of versions.
    
    if(str(versionList[i]) != parentVersion):
        nameList.append(str(versionList[i]))
        # This if clause helps us append all versions other than the parent version to a list for recreation.
        
    i = i + 1


# In[6]:


ownerList = []
jobList = []
fullList = []
# I created 3 lists here to split the owner of the version, the version name, and a list to combine them with proper parameters.

j = 0

while(j < len(nameList)): # I used another while list because the version amount could be any amount.
    ownerList.append(nameList[j].split(".", 1)[0]) # Here I split nameList to populate the owner list with the version owners.
    
    jobList.append(nameList[j].split(".", 1)[1]) # Here I split the nameList to populate the job list with the job names.
    
    if ownerList[j] == "SDE": # If the owner is SDE, then it will only provide the job name to prevent compounding version names.
        fullList.append(jobList[j])
        
    else: # If the owner is any user authenticated owner, it should add the owner's name to the version name.
        fullList.append(ownerList[j] + " " + jobList[j])
    
    j = j + 1


# In[8]:


arcpy.ReconcileVersions_management(workspace, "ALL_VERSIONS", "sde.DEFAULT", versionList, "LOCK_ACQUIRED", "NO_ABORT", "BY_ATTRIBUTE", "FAVOR_EDIT_VERSION", "POST", "DELETE_VERSION", "C:\Users\pwyate36\Desktop\Compression_Scripts\Log_Files\ProposedFeaturesScript_NoRecreation_reconcilelog.txt")
# Here we reconcile, post, and confirm the versions using an arcpy tool. We want to have it go by attribute 
# and favor the edited version. This will also produce a reconcile log to whichever path you specify above.
print("Version reconciliation complete.")

# In[9]:


arcpy.Compress_management(workspace) # Here we are compressing the database, only one person can be online for proper compression.
print("Compression of database complete.")

# In[10]:


arcpy.RebuildIndexes_management(workspace, "SYSTEM") # Here we are rebuilding the indexes of the database after compression.
print("Rebuilding indexes of database complete.")

# In[11]:


arcpy.AnalyzeDatasets_management(workspace, "SYSTEM") # Here we are analyzing the datasets to ensure the base tables are correct.
print("Analyze datasets for base tables complete.")

# In[ ]:


n = 0

while(n < len(fullList)): # I used a while list again just to make sure that there's no problems with large version sets.
    versionName = fullList[3:n] # Here we assign each fullList string to a variable to call for them when we create the versions.
    
    arcpy.CreateVersion_management(workspace, parentVersion, versionName, "PUBLIC")
    # Here we are recreating the versions using the fullList to include the owner's name and the job name as the version name.
    # These versions should be fully editable by those working on different projects regardless of current owner.
    
    n = n + 1

print("Versions are now recreated in ArcMap.")

# In[ ]:


# Reconnects users
print("Allow users to connect to the database again")
arcpy.AcceptConnections(workspace, True)


# In[ ]:


print("Proposed Features Batch Reconcile and Post Versions - Script Finished.")

